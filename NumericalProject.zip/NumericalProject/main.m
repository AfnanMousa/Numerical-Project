%x0=4;
%iter_max=15;
%es=0.01;
%g =@(x)(power(x,2)-3)/2;
%FixedPoint(x0,iter_max,es,g);